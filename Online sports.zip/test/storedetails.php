<?php
$productname=$_POST["pname"];
$sporttype=$_POST["stype"];
$company=$_POST["company"];
$model= ucwords($_POST["model"]);
$price=$_POST["price"];
$desc=$_POST["desc"];
$discount=$_POST["discount"];
$afterdiscount=$_POST["aftdisc"];

$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}

if(isset($_POST['submit'])){

 
$productid=strtoupper($productname).strtoupper($company).strtoupper($model);

$qry="select ifnull(max(sno),0) product_id from productdetails";
$pno=$conn->query($qry);
if($pno)
{
    while($row=$pno->fetch_assoc())
    {
        $count=$row["product_id"]+1; 
    }
}
else
{
    $count=1;
}
include 'adminmenu.php';

$imgname = $_FILES['image']['name'];
 $target_dir = "uploads/";
 

 // Valid file extensions
 $extensions_arr = array("jpg","jpeg","png","gif");

 $img1= explode(".", $imgname);
$image1=$img1[0].$count;
$totalimg=$image1.'.'.$img1[1];

$target_file = $target_dir . $totalimg;
 // Select file type
 $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
 
 // Check extension
 if( in_array($imageFileType,$extensions_arr) ){
 
$sql="insert into productdetails values('$count','$productid','$productname','$model','$company','$sporttype',$price,'$totalimg',0,'$desc',$discount,$afterdiscount)";
$result=$conn->query($sql);
if($result)
{
  // Upload file
    
   if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        echo "<center><h2>The product succeddfully added to the sales list</h2></center>";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}  
else
{
    echo "insertion not success";
}
}

}


?>


