<?php
$pid=$_GET["pid"];
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}

$sql="update productdetails set is_remove=1 where productid='$pid'";
$result=$conn->query($sql);
if($result)
{
    include 'removeproductsdisplay.php';
    echo "<center><h3 style='color:green'>Product has been removed successfully</h3></center>";
}
else
{
    echo "update Unsuccessful";
}