<?php
          session_start();
          $user=$_SESSION["username"];
          $emailid=$_SESSION["usermail"];
          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
          if($conn->connect_error)
            {
                die("Connection failed:$conn->connect_error");
            }
$address=$_POST["address"];
$pin=$_POST["pincode"];
$landmark=$_POST["landmark"];
$prodid=$_POST["pid"];
$pmode=$_POST["mode"];
$quantity=$_POST["qty"];
$city=$_POST['city'];
$town=$_POST['town'];
$state=$_POST['state'];

if($pmode=='PAYTM')
{
    include("https://paytm.com/");
}
else{
$qry="select ifnull(max(id),0) id from orderdetails";
$sno=$conn->query($qry);

if($sno)
{
    while($row=$sno->fetch_assoc())
    {
        $count=$row["id"]+1; 
    }
}
else
{
    $count=1;
}

$order="";
$sql = "select productid,company,productname,model,price,concat(company,' ',productname,' ',model) itemname from productdetails where productid='".$prodid."' and is_remove=0";

$date=date("d-m-Y");
$date1=date("d-m-Y",strtotime($date. ' + 4 days'));


$result =$conn->query($sql);
if($result)
{
    while($row=$result->fetch_assoc())
    {
       $company=$row['company']; 
       $productname=$row['productname'];
       $model=$row['model']; 
       $price=$row['price'];
       $itemname=$row['itemname'];
       $uniqueId= time().mt_rand();
       if($price>1000)
        {
            $charges=0;
        }
        else
        {
            $charges=40;
        }
       $qry="insert into orderdetails values($count,'$prodid','$productname','$company','$model',"
               . "'$price',$charges,$pin,'$address','$landmark',0,0,'$pmode','$emailid',$quantity,NOW(),'$uniqueId','$city','$town','$state')";
     
       $total=($price*$quantity)+$charges;
       $res =$conn->query($qry);
       if($res)
       {
           require 'PHPMailer-5.2.25/PHPMailerAutoload.php';
        $mail = new PHPMailer;
        $email=$emailid;//to reciepients
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = '13cp020@gmail.com';
        $mail->Password = 'Srinath.g14';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->addAddress($email);
        $mail->Subject = '';
        $mail->isHTML(true);

        $mailContent = "<center>
            <h1>Your Order has been place successfully with order no. $uniqueId</h1>
            <h2>Your order will be delivered on or before $date1</h2>
            <h2>Order Invoice</h2>
        <table border='1' width='100%'>
            <tr>
                <td>
                    Billing Address
                </td>
                 <td>
                     $address, $town, $city, $state
                 </td>
            </tr>
        </table><br><br>
        <table border='1' width='100%'>
            <tr>
                <th>Item name</th> 
                <th>Quantity</th> 
                <th>Price</th> 
            </tr>
            <tr>
                <td>$itemname</td> 
                <td>$quantity</td> 
                <td>$price</td> 
            </tr>
            <tr>
                <td colspan='2'>Delivery Charge</td>
                <td>$charges</td>
            </tr>
             <tr>
                <td colspan='2'>Total</td>
                <td>$total</td>
            </tr>
        </table></center>
";
        $mail->Body = $mailContent;//body or content
        if(!$mail->send()){
       // echo 'Message could not be sent.';
        $order="failed";
        echo 'Mailer Error: ' . $mail->ErrorInfo;
        }else{
            $order="success";
        //echo 'Message has been sent';
        }
        
       }
    }
    
}


if($order=="success")
{
    
  $sql="update cartdetails set is_added=0 where prodid='$prodid' and email like '$emailid'";
$result=$conn->query($sql);
if($result)
{
    include 'cart.php';
    echo "<h3> Your order has been placed Successfully with order ID: $uniqueId</h3><br>"
            . "<h4>Your order will be delivered on or before $date1<h4>";
}
else
{
    echo "update Unsuccessful";
}

}
 else {
    echo "Order not Placed Successfully";
}
}