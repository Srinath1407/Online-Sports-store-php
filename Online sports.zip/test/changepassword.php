<html>
    <head>
        <link href="css/mycss.css" rel="stylesheet" type="text/css"/>
    </head>
</html>

<?php
session_start();
$name=$_SESSION["username"];
$mail=$_SESSION["usermail"];
$oldpwd=$_POST["oldpwd"];
$newpwd=$_POST["npwd"];

$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}
$qry="select * from registration where email like '".$mail."' and password like '".$oldpwd."'";
$sno=$conn->query($qry);
  $qry = "select is_admin from registration where email like '$mail'";
          $res =$conn->query($qry);
          $page="";
          if($res)
          {
              while($row=$res->fetch_assoc())
              {
               $admin=$row["is_admin"];
              }
          } 
            if($admin==1)
            {
                $page="adminmenu.php";
            }
            else
            {
                $page='home.php';
            }
 $sql="update registration set password='".$newpwd."' where email like '".$mail."'";
if($sno->num_rows)
{
    $update=$conn->query($sql);
    if($update)
    {
        include $page;
        echo "<center><h2 style='margin-top:70px'>Password changed succesfully</h2></center>";
    }
        else
        {
            include $page;
            echo "<center><h2 style='margin-top:70px'>Password not changed</h2></center>";
        }
}
else
{
     include $page;
    echo "<center><h2 style='margin-top:70px'>Incorrect Password entered</h2></center>";
}

?>