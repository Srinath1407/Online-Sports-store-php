<html>
    <head>
       <link rel="stylesheet" href="css/bootstrap.min.css">
        <style>
           ul{
            padding: 0;
            list-style: none;
            background: #f2f2f2;
        }
        .menu{
            
        }
        ul li{
            display: inline-block;
            position: relative;
            line-height: 21px;
            text-align: left;
            
        }
        ul li a{
            display: block;
            padding: 8px 25px;
            color: #333;
            text-decoration: none;
        }

        ul li a:hover{
            color: #fff;
            text-decoration: none;
            background: #939393;

        }

        ul li ul.dropdown{
            min-width: 100%; /* Set width of the dropdown */
            background: #f2f2f2;
            display: none;
            position: absolute;
            z-index: 999;
            left: 0;
        }
        ul li:hover ul.dropdown{
            display: block; /* Display the dropdown */
        }

        ul li ul.dropdown li{
            display: block;
        }

            
.frmSearch {border: 1px solid #a8d4b1;background-color: #c6f7d0;margin: 2px 0px;padding:40px;border-radius:4px;}
#product-list{float:left;list-style:none;margin-top:-3px;padding:0;width:500px;position: absolute;}
#product-list li{padding: 10px; background: #f0f0f0; border-bottom: #bbb9b9 1px solid;}
#product-list li:hover{background:#ece3d2;cursor: pointer;}
#search-box{padding: 10px;border: #a8d4b1 1px solid;border-radius:4px;}

#search-box{    
background-image:url(css/search.png);   
background-position:right;   
background-repeat:no-repeat;
background-size: 25px;
padding-left:17px;
}
       
.menu {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  height: 50px;
 
}
 
            
        </style>
       <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
         <script>
$(document).ready(function(){
	$("#search-box").keyup(function(event){
                        event.preventDefault();
               if (event.keyCode === 13) {
                   document.getElementById("click").click();
                   document.getElementById("#suggesstion-box").style.display=none;
               }
		$.ajax({
		type: "POST",
		url: "readproducts.php",
		data:'keyword='+$(this).val(),
		beforeSend: function(){
			$("#search-box").css("background","#FFF url(css/LoaderIcon.gif) no-repeat 450px");
		},
		success: function(data){
			$("#suggesstion-box").show();
			$("#suggesstion-box").html(data);
			$("#search-box").css("background","#FFF");
		}
		});
	});
});

$(window).bind('scroll', function () {
    if ($(window).scrollTop() > 10) {
        $('.menu').addClass('fixed');
    } else {
        $('.menu').removeClass('fixed');
    }
});


function selectProduct(val) {
    var pname="";
    if(val.value=="")
    {
        pname=$("#search-box").val();
    }
    else
    {
        pname=val;
        $("#search-box").val(val);
    }
//$("#search-box").val();
$("#suggesstion-box").hide();
$("#products").hide();
$("#products1").hide();
$("#productsdata").hide();

$.ajax({
		type: "POST",
		url: "seachproducts.php",
		data:'keyword='+pname,
                success: function(data){
			$("#items").html(data);
		}
                });
}

</script>
    </head>
    <body class="container-fluid">
       
        <h2 style="text-align:center;color:purple;">
            
        </h2>
        <h4>
            <div id="list" class="menu" >

        <ul>
            <li><a href="display.php" > Sports store <img src='css/logo.png' height='25' width='27'></a></li>
       

         <?php
            session_start();
            if($_SESSION["username"]=="")
            {
                echo "<li><a href='login.php'>Login</a></li>";
                 echo "<li><a href='register.php'>Register/Signup</a></li>";
            }
            ?>
            
              <li>
                  <input type="text" name="city"  id="search-box" style="width: 500px" >
                  <input type="hidden" id="click" onclick="selectProduct(this)">
                  <div id="suggesstion-box"></div>
                  </li>
              <li><a href="cart.php" >
                     <?php
                     session_start();
          $user=$_SESSION["username"];
          $mail=$_SESSION["usermail"];
          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
          if($conn->connect_error)
            {
                die("Connection failed:$conn->connect_error");
            }
if($mail=="")
{
    $mail="empty";
}
$prodid=$_GET["pid"];
$sql = "select count(*) count from cartdetails where email='".$mail."' and is_added=1";
$result =$conn->query($sql);

if($result)
{
    while($row=$result->fetch_assoc())
    {
       $count=$row['count']; 
    }
}
if($count>0)
{
    echo "cart <img src='css/cart.png' height='25' width='27'>"."$count";
}
 else {
    echo "cart";
}                
                     ?>
                     </a></li>
                           
                      <li>

                <a href="#"><?php
           if($_SESSION["username"]!="")
            {
            echo "Welcome ".$_SESSION["username"];
            }
            ?></a>

                <ul class="dropdown">

                    <?php
            if($_SESSION["username"]!="")
            {
                echo "<li><a href='yourorders.php'>Your Orders</a></li>";
                echo "<li><a href='changepassworddisplay.php'>Change Password</a></li>";
                 echo "<li><a href='logout.php'>Logout</a></li>";
            }
            ?>
                </ul>

            </li>
              
              
              

        </ul>

        </div >
        </h4>
        </nav>
        <div id="items"></div>
    </body>
</html>
