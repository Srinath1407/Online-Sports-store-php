<?php
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}
$sql = "select image from images";
$result =$conn->query($sql);
if($result)
{
    while($row=$result->fetch_assoc())
    {
       $image = $row['image']; 
    }
}


$image_src = "uploads/".$image;
echo "$image_src<br>";

?>
<img src='<?php echo $image_src;  ?>' >