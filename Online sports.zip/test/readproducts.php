<?php
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}
//echo "fasfs";
if(!empty($_POST["keyword"])) {
$query ="select concat(company,' ',productname,' ',model)as productnames,is_remove from productdetails having productnames like '%" . $_POST["keyword"] . "%' and is_remove=0 LIMIT 0,6";
$result=$conn->query($query);
if($result->num_rows) {
?>
<ul id="product-list">
<?php
foreach($result as $product) {
?>
<li onClick="selectProduct('<?php echo $product["productnames"]; ?>');"><?php echo $product["productnames"]; ?></li>
<?php } ?>
</ul>
<?php
} 
else
{
 ?>  
<ul id="product-list">
<li>No products available</li>
</ul>
<?php
}
}
                                