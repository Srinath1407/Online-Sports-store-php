<?php

  session_start();
          $user=$_SESSION["username"];
          $mail=$_SESSION["usermail"];
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}

$qry="select email from cartdetails where is_added=1 and email='empty'";
$res=$conn->query($qry);
echo "widow clise";
$res1="";
if($res){
    while($row=$res->fetch_assoc())
    { 
        $mail=$row["email"];
        $qry1="delete from cartdetails where prodid='$pid' and is_added=1";
        $res1=$conn->query($qry1);
        
    }
   
}