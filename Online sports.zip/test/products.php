<html>
    <head>
       
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link href="css/mycss.css" rel="stylesheet" type="text/css"/>
         <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
       
         <script>
            function hide1()
            {
                if($("#type").val()=="")
                {
                    alert("Enter sports type");
                }
                else
                {
                $("#listdata").hide();
                $("#product").submit();
                }
            }
            </script>
    </head>
    <body class="container-fluid">
        <?php
            include 'adminmenu.php';
        ?>
    <center>
        <h2 style="margin-top: 70px">Add Product Type</h2>
        <form  action="productsinsert.php" method="POST" enctype='multipart/form-data' id="product">
            <table border="0" style="margin-top: 10px">
                <tbody>
                    <tr>
                        <td><label>Enter Sports Type</label></td>
                        <td> <input type="text" name="sporttype" id="type" required="true"></td>
                    </tr>   
                    <tr>
                        <td><input type="button" value="Submit" onclick="hide1()" class="btn btn-danger"></td>
                        <td><input type="reset" value="Reset" class="btn btn-danger"></td>
                    </tr>
                </tbody>
            </table>         
            
         </form>
        </center>
    <h3>Existing Product Types</h3>
    <?php
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}
$qry="select prod_type from product_types";
$pno=$conn->query($qry);
if($pno->num_rows)
{
    echo "<ol id='listdata'>"."";
    while($row=$pno->fetch_assoc())
    {
        $product_type=$row["prod_type"];
        
        echo "<h3><li>$product_type</li></h3>"."";
       
    }
     echo "</ol>";
}


?>
    </body>
</html>







