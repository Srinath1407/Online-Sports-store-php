<?php
$product_type=$_POST["sporttype"];
$pid=strtoupper($product_type);
$ptype= ucfirst($product_type);
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}


/*$qry="select ifnull(max(product_id),0) product_id from products_type";
$pno=$conn->query($qry);
if($pno)
{
    while($row=$pno->fetch_assoc())
    {
        $count=$row["prod_num"]+1; 
    }
}
else
{
    $count=1;
}*/
//include 'adminmenu.php';
$sql="insert into product_types values('$pid','$ptype')";
$result=$conn->query($sql);
if($result)
{
    //echo "Sports type inserted Successfully";
    include 'products.php';
}
else
{
    echo "Sports type insertion Unsuccessful";
}





