<?php
$name=$_POST["name"];
$mobile=$_POST["mobile"];
$email=$_POST["email"];
$password=$_POST["password"];
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}
$qry="select ifnull(max(sno),0) sno from registration";
$sno=$conn->query($qry);

if($sno)
{
    while($row=$sno->fetch_assoc())
    {
        $count=$row["sno"]+1; 
    }
}
else
{
    $count=1;
}
date_default_timezone_set("Asia/Kolkata");
$date=date('d-m-Y');

$sql="insert into registration values($count,'$name',$mobile,'$email','$password',CURDATE(),0)";
echo "$sql";
$result=$conn->query($sql);
if($result)
{
    include 'home.php';
    echo "<center><h2 style='margin-top:70px'>Registration Successful</h2></center>";
}
else
{
    echo "<center><h2>Registration Unsuccessful</h2></center>";
}

?>


