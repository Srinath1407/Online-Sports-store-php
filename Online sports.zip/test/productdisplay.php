<?php



?>

<html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function(){
	$("#qty").change(function(){
		var qty=$("#qty").val();
                var price=$("#orgprice").text();
                alert(price);
                var p=qty*price;
                $("#price").text('Rs. '+p);
	});
});

function submitdetails(id)
            {
                //event.preventDefault();
           
          
                var idvalue=id.id;
                
                var num=idvalue.split('w')[1];
                var pid=$("#pid"+num).val();
                var quantity=$("#qty"+num).val();
                var url='placeorder.php?pid='+pid+'&qty='+1;
                window.location.assign(url);
            
                
            }
        </script>
    </head>
    <body>
        <table cellspacing="50" width="70%" id="productsdata" style="margin-top: 90px">
            <?php
          session_start();
          $user=$_SESSION["username"];
          $mail=$_SESSION["usermail"];
          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
          if($conn->connect_error)
            {
                die("Connection failed:$conn->connect_error");
            }
          $qry = "select is_admin from registration where email like '$mail'";
          $res =$conn->query($qry);
          if($res)
          {
              while($row=$res->fetch_assoc())
              {
               $admin=$row["is_admin"];
              }
          } 
            if($admin==1)
            {
                include 'adminmenu.php';
            }
            else
            {
                include 'home.php';
            }

$prodid=$_GET["pid"];
$sql = "select productid,concat(company,' ',productname,' ',model) product,price,image,proddesc,discount,aftdisc from productdetails where productid='".$prodid."' and is_remove=0";
$result =$conn->query($sql);
//$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
//echo "$actual_link

//$query="select email from cartdetails where prodid='$prodid' and email='$mail'";
//$res1=$conn->query($query);


if($result)
{
    $count=0;
    while($row=$result->fetch_assoc())
    {
       $image=$row['image']; 
       $product=$row['product'];
       $price=$row['price'];
       $pid=$row["productid"];
        $discount=$row["discount"];
       $aftdisc=$row["aftdisc"];
       $image_src = "uploads/".$image;
       $desc=$row["proddesc"];
           
        print "<tr align='center'>";
        print "<td align='center'>";
                echo "<img src='$image_src' height='350px' width='400px'><br>"."";
                print "</td>";
                print "<td align='center'>";
                echo "<h4>$product</h4><br><h4>Rs. ".$aftdisc." $discount% OFF <del>$price</del><h4>";
               echo "<input type='hidden' value='$pid' name='pid' id='pid$itemcount'>";
                echo "$desc<br><br>";
                  if($admin!=1)
            {
                echo ""."<a href='addtocart.php?pid=$pid' class='btn btn-primary'>Add to cart</a>         "."<a href='javascript:void(0)' class='btn btn-primary' id='buynow$itemcount' onclick='submitdetails(buynow$itemcount)'>Buy Now</a>";
            }      
        }
        if ($count > 0) {
        print "</tr>";
    }
}

?>
        
        </table>
    </body>
    
</html>



