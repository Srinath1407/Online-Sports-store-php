<html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
        
        
        <script>	

            function pricecal(a)
            {
                var qtyid=a.id;
                var qty=a.value;
                var quantityid=qtyid.split('y')[1];
                var price=$("#orgprice"+quantityid).val();
                var p=qty*price;
                $("#price"+quantityid).text('Rs. '+p);
            };

            function submitdetails(id)
            {
                //event.preventDefault();
           
          
                var idvalue=id.id;
                
                var num=idvalue.split('w')[1];
                var pid=$("#pid"+num).val();
                var quantity=$("#qty"+num).val();
                var url='placeorder.php?pid='+pid+'&qty='+quantity;
                window.location.assign(url);
            
                
            }
            
            

/*$(document).ready(function(){
	$("#buynow").click(function(){
             var url=$(this).attr('href');
		$.ajax({
		type: "POST",
		url: url+,
		data:'type='+$(this).val(),
		success: function(data){
			$("#display").html(data);
		}
		});
	});
});*/

        </script>
        
    </head>
    <body>
        <form action="placeorder.php" method="POST">
            <table cellspacing="50" width="70%" style="margin-top: 70px">
            <?php
          session_start();
          $user=$_SESSION["username"];
          $mail=$_SESSION["usermail"];
          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
          if($conn->connect_error)
            {
                die("Connection failed:$conn->connect_error");
            }
          $qry = "select is_admin from registration where email like '$mail'";
          $res =$conn->query($qry);
          if($res)
          {
              while($row=$res->fetch_assoc())
              {
               $admin=$row["is_admin"];
              }
          } 
            if($admin==1)
            {
                include 'adminmenu.php';
            }
            else
            {
                include 'home.php';
            }


            
$sql = "select productid,concat(company,' ',productname,' ',model) product,price,image,discount,aftdisc from productdetails where productid in (select productid from orderdetails where usermail like '$mail' and is_canceled=0)";
$result =$conn->query($sql);
if($result->num_rows)
{
    $count=0;
    $itemcount=1;
    while($row=$result->fetch_assoc())
    {
       $image=$row['image']; 
       $product=$row['product'];
       $price=$row['price'];
       $pid=$row["productid"];
       $image_src = "uploads/".$image;
        $discount=$row["discount"];
       $aftdisc=$row["aftdisc"];
      
           
       $qry="select is_delivered,is_canceled,quantity from orderdetails where usermail like '$mail' and productid='$pid'";
       $res=$conn->query($qry);
       
       while($row1 = $res->fetch_assoc())
       {
       $isdeliver=$row1['is_delivered'];
       $iscanceled=$row1['is_canceled'];
       $quantity=$row1['quantity'];
      
       }
        print "<tr align='center'>";
        print "<td align='center'>";
                echo "<img src='$image_src' height='350px' width='400px'><br>"."";
                print "</td>";
                print "<td>";
                echo "<h4>$product</h4><br><h4>Rs. ".$aftdisc." $discount% OFF <del>$price</del><h4>";
                 echo "<input type='hidden' value='$price' id='orgprice$itemcount'>";
                echo "<select name='quantity' id='qty$itemcount' onchange='pricecal(qty$itemcount);' value=$quantity readonly>"."";
               
                     echo "<option value=$quantity>$quantity</option>";
                
                echo "</select>";
                echo "<input type='hidden' value='$pid' name='pid' id='pid$itemcount'>";
                  if($admin!=1 && $isdeliver==0 && $iscanceled==0)
            {
                echo "<a href='cancelorder.php?pid=$pid' class='btn btn-primary'>Cancel Order</a>";
            }    
            else if($isdeliver==1)
            {
                echo "<center><h2 style='margin-top:70px'>Order is delivered</h2></center>";
            }
            else {
                echo "<center><h2 style='margin-top:70px'>You have placed no orders</h2></center>";
            }
            $itemcount++;
        }
        if ($count > 0) {
        print "</tr>";
    }
}

else {
                echo "<center><a href='display.php'><h2 style='margin-top:70px' id='noorder'>You have placed no orders</h2></a></center>";
            }

?>
        
        </table>
        </form>
    </body>
    
</html>




