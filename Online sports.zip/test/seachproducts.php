<?php
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}
//echo "fasfs";

if(!empty($_POST["keyword"])) {
$query ="select  productid,concat(company,' ',productname,' ',model) productnames,is_remove,price,image,discount,aftdisc from productdetails  having productnames like '%" . $_POST["keyword"] . "%' and is_remove=0 ORDER BY productname ";
    $result=$conn->query($query);
    echo "<table cellspacing='50' width='100%' style='margin-top:70px'>";
if($result->num_rows) {
    
     $count=0;
    $rowcount=1;
    while($row=$result->fetch_assoc())
    {
       $image = $row['image']; 
       $product=$row['productnames'];
       $price=$row['price'];
       $pid=$row["productid"];
       $discount=$row["discount"];
       $aftdisc=$row["aftdisc"];
       $image_src = "uploads/".$image;
      
            if($count==4) 
            {
               print "</tr>";
               $count = 0;
            }
            if ($count == 0) {
            print "<tr align='center'>";
        }
        print "<td>";
            
            echo "<img src='$image_src' height='180px' width='200px'><br><a href='productdisplay.php?pid=$pid'>$product</a><br><h4>Rs. ".$aftdisc." $discount% OFF <del>$price</del><h4>"."";
            if($admin!=1 and $count1==0)
            {
              //  echo ""."<a href='addtocart.php?pid=$pid' class='btn btn-primary' id='addcart$rowcount' onclick='hideadd()'>Add to cart</a>";
            }     
            if($prodid==$pid)
            {
               // echo ""."<a href='cart.php' class='btn btn-primary' id='gocart$rowcount'>Go to cart</a>";
            }
            $count++;
            $rowcount++;
            print "</td>";
        }
        if ($count > 0) {
        print "</tr>";
    }
}
else
{
    echo "<center><h2>No Products available</h2></center>";
}
echo "</table>";
} 
                
    
                

