<html>
    <head>
        
        <link rel="stylesheet" href="css/bootstrap.min.css">
                    
    </head>
    <body class="container-fluid">
<?php
session_start();

$username=$_POST["user"];
$password=$_POST["lpassword"];
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}
if($mail=="")
{
    $mail="empty";
}
$prodid=$_POST["prodid"];
$qry="select email from cartdetails where email='$mail' and prodid='$prodid' and is_added=1";
$res=$conn->query($qry);
if($res){
    while($row=$res->fetch_assoc())
    {
        $usermail=$row["email"];
    }
    if($usermail=='empty' || empty($usermail))
    {
        $sql = "select productid,company,productname,model,price from productdetails where productid='".$prodid."'";
$result =$conn->query($sql);
if($result)
{
    $count=0;
    while($row=$result->fetch_assoc())
    {
       $image=$row['image']; 
       $product=$row['productname'];
       $model=$row['model'];
       $price=$row['price'];
       $pid=$row["productid"];
      
     }
       $qry="insert into cartdetails (email,prodname,model,price,is_added,prodid) values('$username','$product','$model',$price,1,'$pid')";
      
       $qryres=$conn->query($qry);
       if($qryres)
       {
          //include 'cart.php';
       }
        else {
       // echo "not added to cart"  ;
       }

}
    }
    else
    {
        //include 'cart.php'; 
        echo "already added to cart";
    }
    
}




$qry="select name,email from registration where email like '".$username."' and password like '".$password."' and is_admin=0";
$qry1="select name,email from registration where email like '".$username."' and password like '".$password."' and is_admin=1";

$result=$conn->query($qry);
$result1=$conn->query($qry1);

if($result->num_rows)
{
    //$sql1="select name from registration where email like"
    $val=$result->fetch_assoc();
    $_SESSION["username"]=$val["name"];
    $_SESSION["usermail"]=$val["email"];
    include 'display.php';

}
 else if($result1->num_rows){
     
    $val=$result1->fetch_assoc();
    $_SESSION["username"]=$val["name"];
    $_SESSION["usermail"]=$val["email"];
     include 'display.php';

}
 else {
    include 'login.php';    
echo "<h4 style='color:red;margin-top:70px'>incorrect username/password</h4>";    

}

?>

        
    </body>
</html>




