<html>
    <head>
        

<script type = "text/javascript" >

   function preventBack(){window.history.forward();}

    setTimeout("preventBack()", 0);

    window.onunload=function(){null};

</script>

    </head>

<?php
session_start();
session_destroy();
session_unset();
$_SESSION= array();
include 'display.php';
?>
</html>
