<html>
    <head>
        <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
        <script>
$(document).ready(function(){
	$("#stype").change(function(){
		$.ajax({
		type: "POST",
		url: "retriveproducts.php",
		data:'type='+$(this).val(),
		success: function(data){
			$("#display").html(data);
		}
		});
	});
});
</script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
                   
    </head>
    <body class="container-fluid">
        <?php
            include 'adminmenu.php';
        ?>
    <center>
        <h2>Remove products from sale</h2>
        <form  action="storedetails.php" method="POST" enctype='multipart/form-data'>
            <table border="0">
                <tbody>    
                    <tr>
                        <td><label>Sport Type</label></td>
                        <td> <select name="stype" id="stype">
                                
                            <?php
                          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
                          if($conn->connect_error)
                          {
                              die("Connection failed:$conn->connect_error");
                          }
                          $qry="select pid,prod_type from product_types";
                          $pno=$conn->query($qry);
                          if($pno->num_rows)
                          {
                              echo "<ul>"."";
                              while($row=$pno->fetch_assoc())
                              {
                                  $product_type=$row["prod_type"];
                                  $pid=$row["pid"];
                                            
                                 

                              }
                          }


                          ?>
                            </select>
                        </td>
                    </tr> 
                    
                   
                </tbody>
            </table>         
         </form>
        <div id="display">
            
        </div>
        </center>
    </body>
</html>





