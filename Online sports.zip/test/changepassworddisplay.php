
<?php
 session_start();
          $user=$_SESSION["username"];
          $mail=$_SESSION["usermail"];
          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
          if($conn->connect_error)
            {
                die("Connection failed:$conn->connect_error");
            }
          $qry = "select is_admin from registration where email like '$mail'";
          $res =$conn->query($qry);
          if($res)
          {
              while($row=$res->fetch_assoc())
              {
               $admin=$row["is_admin"];
              }
          } 
            if($admin==1)
            {
                include 'adminmenu.php';
            }
            else
            {
                include 'home.php';
            }
?>
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script>
            function checkPwd()
            {
                var pwd1=document.getElementById("npwd").value;
                var pwd2=document.getElementById("cpwd").value;
                if(pwd1!=pwd2)
                {
                    alert("Confirm the password correctly");
                    document.getElementById("cpwd").value="";
                }
            }
            </script>
    </head>
    <body class="container-fluid">
    <center>
        <h2 style="margin-top: 70px">Change Password</h2>
        <form  action="changepassword.php" method="POST">
            <table border="0" style="margin-top: 30px">
                <tbody> 
                    <tr>
                        <td> <label>Enter Old Password</label></td>
                        <td><input type="password" name="oldpwd" required="true"></td>
                    </tr>
                    <tr>
                        <td> <label>New Password</label></td>
                        <td><input type="password" name="cpwd" id="npwd" required="true"></td>
                    </tr>
                    <tr>
                        <td> <label>Confirm Password</label></td>
                        <td><input type="password" name="npwd" id="cpwd" required="true" onblur="checkPwd()"></td>
                    </tr>
                    <tr>
                        <td><input type="submit" value="Change" class="btn btn-danger"></td>
                        <td><input type="reset" value="Reset" class="btn btn-danger"></td>
                    </tr>
                </tbody>
            </table>         
            
            
         </form>
        </center>
    </body>
</html>
