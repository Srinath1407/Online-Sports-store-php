<?php
          session_start();
          $user=$_SESSION["username"];
          $mail=$_SESSION["usermail"];
          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
          if($conn->connect_error)
            {
                die("Connection failed:$conn->connect_error");
            }
         

$prodid=$_GET["pid"];

if($mail=="")
{
    $mail="empty";
}

$qry="select email from cartdetails where email='$mail' and prodid='$prodid' and is_added=1";
$res=$conn->query($qry);
if($res){
    while($row=$res->fetch_assoc())
    {
        $usermail=$row["email"];
    }
    if($usermail=='empty' || empty($usermail))
    {
        $sql = "select productid,company,productname,model,price,proddesc,discount,aftdisc from productdetails where productid='".$prodid."'";
$result =$conn->query($sql);
if($result)
{
    $count=0;
    while($row=$result->fetch_assoc())
    {
       $image=$row['image']; 
       $product=$row['productname'];
       $model=$row['model'];
       $price=$row['aftdisc'];
       $pid=$row["productid"];
      
     }
       $qry="insert into cartdetails (email,prodname,model,price,is_added,prodid) values('$mail','$product','$model',$price,1,'$pid')";
       $qryres=$conn->query($qry);
       if($qryres)
       {
          include 'cart.php';
       }
        else {
        echo "<center><h2 style='margin-top:70px'>not added to cart</h2></center>"  ;
       }

}
    }
    else
    {
        
        echo "<center><h4 style='margin-top:70px'>already added to cart</h4></center>";
        include 'cart.php'; 
    }
    
}



?>