<html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
    </head>
    <body class="container-fluid">
          <?php
            include 'home.php';
        ?>
        <center>
        <h2>Placing Order</h2>
        <form  action="storeorderdetails.php" method="POST" enctype='multipart/form-data'>
            <input type="hidden" value="<?php echo $prodid?>" name="pid">
            <table border="0">
                <tbody>
                    <tr>
                        <td><label>Delivery Address</label></td>
                        <td> <textarea rows="4" cols="30" name="address"></textarea></td>
                         
                    </tr>    
                    <tr>
                         <td><label>Pin code</label></td>
                          <td> <input type="text" name="pincode"></td>
                    </tr>
                    <tr>
                        <td><label>Landmark (Optional)</label></td>
                          <td> <input type="text" name="landmark"></td>
                    </tr>
                     <tr>
                        <td><label>Payment Mode</label></td>
                        <td> <select name="mode">
                                  <option value="CASH">CASH</option>
                                  <option value="PAYTM">PAYTM</option>
                              </select>
                              </td>
                    </tr>
                    <tr>
                         <td><input type="submit" value="Place Order"></td>
                    </tr>
                </tbody>
            </table>
        </form>
        </center>
    </body>
</html>

