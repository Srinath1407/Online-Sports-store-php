<?php

          session_start();
          $user=$_SESSION["username"];
          $mail=$_SESSION["usermail"];
          $prodid=$_GET["pid"];
          $quantity=$_GET["qty"];
         $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
          if($conn->connect_error)
            {
                die("Connection failed:$conn->connect_error");
            }
          $sql="select aftdisc from productdetails where productid='$prodid'";
          $res=$conn->query($sql);
          $price="";
          if($res->num_rows)
          {
              while($row=$res->fetch_assoc())
              {
                  $price=$row["aftdisc"];
              }
          }
        
            if($mail=="")
            {
                
                $_GET["prodid"]=$prodid;
                include 'login.php';
                echo "<center><h3 style='color:red'>Please login to place order</h3>";
            }
            else{
               
                
                ?>

 <html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
    </head>
    <body class="container-fluid">
        <?php
     
          include 'home.php';
        ?>
        <center>
            <h2 style="margin-top: 70px">Placing Order</h2>
          
        <form  action="storeorderdetails.php" method="POST" enctype='multipart/form-data'>
            
            <input type="hidden" value="<?php echo $quantity?>" name="qty">
            <input type="hidden" value="<?php echo $prodid?>" name="pid">
            <table border="0" style="margin-top: 40px" >
                <tbody>  
                    <tr>
                        <td><label>Amount Payable</label></td>
                        <td><?php echo $price.' x '.$quantity."<br>";
                           
                            $price=$price*$quantity;
                            if($price>1000)
                            {
                                $charges=0;
                            }
                            else
                            {
                                $charges=40;
                            }
                             echo "Delivery Charges:Rs.".$charges."<br>Total: ";
                            echo $price+$charges;?></td>
                         
                    </tr>
                    <tr>
                         <td><label>City</label></td>
                         <td> <input type="text" name="city" ></td>
                    </tr>
                    <tr>
                         <td><label>Town/Village Name</label></td>
                         <td> <input type="text" name="town"></td>
                    </tr>
                    <tr>
                        <td><label>Complete Address</label></td>
                        <td> <textarea rows="4" cols="30" name="address" maxlength="100" placeholder="House No. ,street name,etc.,"></textarea></td>   
                    </tr>
                    <tr>
                         <td><label>State</label></td>
                         <td> <input type="text" name="state" ></td>
                    </tr>
                    <tr>
                         <td><label>Pin code</label></td>
                         <td> <input type="text" name="pincode" maxlength="6"></td>
                    </tr>
                    <tr>
                        <td><label>Landmark (Optional)</label></td>
                          <td> <input type="text" name="landmark"></td>
                    </tr>
                     <tr>
                        <td><label>Payment Mode</label></td>
                        <td> <select name="mode">
                                  <option value="CASH">CASH</option>
                                  <option value="PAYTM">PAYTM</option>
                              </select>
                              </td>
                    </tr>
                    <tr>
                         <td><input type="submit" value="Place Order"></td>
                    </tr>
                </tbody>
            </table>
        </form>
        </center>
    </body>
</html>

<?php
            }
     ?>       
            


