<html>
    <head>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/mycss.css" rel="stylesheet" type="text/css"/>
         <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
       <script type="text/javascript">
           
        function readURL(input) {
           
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $("#blah").attr("src", e.target.result);
                }
                reader.readAsDataURL($(this)[0].files[0]);
            }
        }
        
         function discountCal()
        {
          
            var discount=document.getElementById("disc").value;
            if(discount>100)
            {
                alert("discount should be less than 100");
                document.getElementById("disc").value="";
            }
            else{
            var orgprice=document.getElementById("orgprice").value;
            var disc=orgprice*(discount/100);
             var afterdisc=orgprice-disc;
           document.getElementById("aftprice").value=afterdisc;
            }
        }
        
         $(document).ready(function(){
            $("#orgprice").keyup(function(){
              $("#orgprice").val($("#orgprice").val().replace(/[^0-9]/gi, ''));
            });
             $("#disc").keyup(function(){
              $("#disc").val($("#disc").val().replace(/[^0-9]/gi, ''));
            });
        });
    </script>
        <link rel="stylesheet" href="css/bootstrap.min.css">
                   
    </head>
    <body class="container-fluid">
        <?php
            include 'adminmenu.php';
        ?>
    <center>
        <h2 style="margin-top: 70px">Add Items for sale</h2>
        <form  action="storedetails.php" method="POST" enctype='multipart/form-data'>
            <table border="0"style="margin-top: 10px">
                <tbody>
                    <tr>
                        <td><label>Product Name</label></td>
                        <td> <input type="text" name="pname" required="true"></td>
                    </tr>     
                    <tr>
                        <td><label>Sport Type</label></td>
                        <td> <select name="stype" required="true">
                                <option value="0">SELECT</option>>
                            <?php
                          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
                          if($conn->connect_error)
                          {
                              die("Connection failed:$conn->connect_error");
                          }
                          $qry="select pid,prod_type from product_types order by prod_type";
                          $pno=$conn->query($qry);
                          if($pno->num_rows)
                          {
                              echo "<ul>"."";
                              while($row=$pno->fetch_assoc())
                              {
                                  $product_type=$row["prod_type"];
                                  $pid=$row["pid"];
                                            
                                  echo "<option value='$pid' name='prodtype'>$product_type</option>"."";

                              }
                          }


                          ?>
                            </select>
                        </td>
                    </tr> 
                    <tr>
                        <td><label>Product Company</label></td>
                        <td> <input type="text" name="company" required="true"></td>
                    </tr>
                    <tr>
                        <td><label>Product Model Number</label></td>
                        <td> <input type="text" name="model"required="true"></td>
                    </tr> 
                     <tr>
                        <td><label>Product Description</label></td>
                        <td> <textarea rows="4" cols="30" name="desc" required="true"></textarea></td>
                    </tr> 
                      <tr>
                        <td><label>Price</label></td>
                        <td> <input type="text" name="price" id="orgprice" required="true"></td>
                    </tr> 
                     <tr>
                        <td><label>Discount</label></td>
                        <td> <input type="text" name="discount" id="disc" placeholder="in %" onblur="discountCal()"></td>
                    </tr> 
                     <tr>
                        <td><label>Price after discount</label></td>
                        <td> <input type="text" name="aftdisc" id="aftprice" readonly="true"></td>
                    </tr> 
                    <tr>
                        <td><label>image</label></td>
                        <td> <input type="file" name="image" onchange="readURL(this)" ></td>
                        <td><img id="blah" src="" /></td>
                    </tr>         
                    <tr>
                        <td><input type="submit" value="Submit" name="submit" class="btn btn-danger"></td>
                        <td><input type="reset" value="Reset"class="btn btn-danger"></td>
                    </tr>
                </tbody>
            </table>         
            
            
         </form>
        </center>
    </body>
</html>





