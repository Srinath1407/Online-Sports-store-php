<?php
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}
$sql = "select productid,concat(company,' ',productname,' ',model) product,price,image from productdetails where producttype like'".$_POST["type"]."' and is_remove=0";
$result =$conn->query($sql);

if($result->num_rows)
{
    $count=0;
    while($row=$result->fetch_assoc())
    {
       $image = $row['image']; 
       $product=$row['product'];
       $price=$row['price'];
       $pid=$row["productid"];
       $image_src = "uploads/".$image;
      
            if($count==4) 
            {
               print "</tr>";
               $count = 0;
            }
            if ($count == 0) {
            print "<tr align='center'>";
        }
        print "<td>";
            
            echo "<img src='$image_src' height='180px' width='200px'><br><a href='productdisplay.php?pid=$pid'>$product</a><br><h4>Rs. ".$price."<h4>"."";
            if($admin!=1 and $count1==0)
            {
                echo ""."<a href='removeproduct.php?pid=$pid' class='btn btn-primary'>Remove</a>";
            }     
            $count++;
            print "</td>";
        }
        if ($count > 0) {
        print "</tr>";
    }
}
else
{
    echo "<h2>No products available under this category</h2>";
}
?>