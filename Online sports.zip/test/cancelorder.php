<?php
$pid=$_GET["pid"];
$conn=new mysqli("localhost:3306", "project", "project", "projectdb");
if($conn->connect_error)
{
    die("Connection failed:$conn->connect_error");
}

$sql="update orderdetails set is_canceled=1 where productid='$pid'";
$result=$conn->query($sql);
if($result)
{
    include 'yourorders.php';
    echo "<center><h2 style='margin-top:70px'>Your Order is canceled successfully</h2></center>";
}
else
{
    echo "<center><h2 style='margin-top:70px'>update Unsuccessful</h2></center>";
}

?>


