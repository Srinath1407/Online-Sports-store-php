<html>
    <head>
         <link rel="stylesheet" href="css/bootstrap.min.css">
        <link href="css/mycss.css" rel="stylesheet" type="text/css"/>
        <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
   
        <script>	
            function pricecal(a)
            {
                var qtyid=a.id;
                var qty=a.value;
                var quantityid=qtyid.split('y')[1];
                var price=$("#orgprice"+quantityid).val();
                var p=qty*price;
                $("#price"+quantityid).text('Rs. '+p);
            }

            function submitdetails(id)
            {
                var idvalue=id.id;
                var num=idvalue.split('w')[1];
                var pid=$("#pid"+num).val();
                var quantity=$("#qty"+num).val();
                var url='placeorder.php?pid='+pid+'&qty='+quantity;
                window.location.assign(url);
       
            }
            
            

/*$(document).ready(function(){
	$("#buynow").click(function(){
             var url=$(this).attr('href');
		$.ajax({
		type: "POST",
		url: url+,
		data:'type='+$(this).val(),
		success: function(data){
			$("#display").html(data);
		}
		});
	});
});*/

        </script>
       
    </head>
    <body>
        <form action="placeorder.php" method="POST">
        <table cellspacing="50" width="70%" style="margin-top: 90px">
            <?php
          session_start();
          $user=$_SESSION["username"];
          $mail=$_SESSION["usermail"];
          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
          if($conn->connect_error)
            {
                die("Connection failed:$conn->connect_error");
            }
          $qry = "select is_admin from registration where email like '$mail'";
          $res =$conn->query($qry);
          if($res)
          {
              while($row=$res->fetch_assoc())
              {
               $admin=$row["is_admin"];
              }
          } 
            if($admin==1)
            {
                include 'adminmenu.php';
            }
            else
            {
                include 'home.php';
            }


 if($mail=="")
{
    $mail="empty";
}           
$sql = "select productid,concat(company,' ',productname,' ',model) product,price,image,proddesc,discount,aftdisc from productdetails where productid in (select prodid from cartdetails where email like '$mail' and is_added=1)";
$result =$conn->query($sql);

if($result->num_rows)
{
    $count=0;
    $itemcount=1;
    while($row=$result->fetch_assoc())
    {
       $image=$row['image']; 
       $product=$row['product'];
       $price=$row['price'];
       $pid=$row["productid"];
       $image_src = "uploads/".$image;
       $discount=$row["discount"];
       $aftdisc=$row["aftdisc"];
      
           
        print "<tr align='center'>";
        print "<td align='center'>";
                echo "<img src='$image_src' height='350px' width='400px'><br>"."";
                print "</td>";
                print "<td>";
                echo "<h4>$product</h4><br><h4 id='price$itemcount'>Rs. ".$aftdisc."</h4><h4> $discount% OFF <del>$price</del><h4>";
                 echo "<input type='hidden' value='$aftdisc' id='orgprice$itemcount'>";
                echo "<select name='quantity' id='qty$itemcount' onchange='pricecal(qty$itemcount);'>"."";
                for ($i = 1;$i < 11;$i++) {
                     echo "<option value=$i>$i</option>";
                }
                echo "</select>";
                echo "<input type='hidden' value='$pid' name='pid' id='pid$itemcount'>";
                  if($admin!=1)
            {
                echo "<a href='javascript:void(0)' class='btn btn-primary' id='buynow$itemcount' onclick='submitdetails(buynow$itemcount)'>Buy Now</a>         "."<a href='removecart.php?pid=$pid' class='btn btn-primary'>Remove</a>";
            }    
            $itemcount++;
        }
        if ($count > 0) {
        print "</tr>";
    }
}
else
{
    echo "<center><h2 style='margin-top:70px'>No products availabe in cart</h2></center>";
}
?>
        
        </table>
        </form>
    </body>
    
</html>




