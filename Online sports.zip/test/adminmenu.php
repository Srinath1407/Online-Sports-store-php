<html>
    <head>
       <link rel="stylesheet" href="css/bootstrap.min.css">
        <style>
            ul{
            padding: 0;
            list-style: none;
            background: #f2f2f2;
        }

        ul li{
            display: inline-block;
            position: relative;
            line-height: 21px;
            text-align: left;
            
        }
        ul li a{
            display: block;
            padding: 8px 25px;
            color: #333;
            text-decoration: none;
        }

        ul li a:hover{
            color: #fff;
            text-decoration: none;
            background: #939393;

        }

        ul li ul.dropdown{
            min-width: 100%; /* Set width of the dropdown */
            background: #f2f2f2;
            display: none;
            position: absolute;
            z-index: 999;
            left: 0;
        }
        ul li:hover ul.dropdown{
            display: block; /* Display the dropdown */
        }

        ul li ul.dropdown li{
            display: block;
        }
    .menu {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  height: 50px;
 
}
        </style>
    </head>
    <body class="container-fluid">
         
        <h4>
        <div id="list" class="menu">

        <ul>

            <li><a href="display.php"> Home </a></li>
        <li><a href="additems.php" > Add Products for sales</a></li>
         <li><a href="products.php">Product Types</a></li>
         <!-- <li><a href="viewsales.php" > View sales </a></li>-->
      <!-- <li><a href="editproductsdisplay.php" >Edit Products</a></li>-->
         <li><a href="removeproductsdisplay.php" >Remove Products</a></li>

         <li><a href="changepassworddisplay.php" > 
               <?php
          session_start();
            if($_SESSION["username"]!="")
            {
                echo "Change Password";
            }
        ?>   
            </a></li> 
             <li><a href="logout.php" >
                 <?php
                 if($_SESSION["username"]!="")
                {    
                     echo "Logout";
                }
                ?>
                 </a></li>    
          <li><a href="#" ><?php
           if($_SESSION["username"]!="")
            {
            echo "Welcome ".$_SESSION["username"];
            }
        ?></a></li>
        </ul>

        </div >
        </h4>
    </body>
</html>




