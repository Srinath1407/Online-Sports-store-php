<html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
    </head>
    <body class="container-fluid">
        <?php include 'home.php';?>
          <center>
       
        <form  action="loginhome.php" method="POST">
           <fieldset>
            <legend>
      <h2>Login</h2></legend>
               <table border="0" style="margin-top: 10px">
                
                <tbody>
                    <tr>
                        <td><label>Email ID</label></td>
                        <td> <input type="text" name="user" required="true"><br></td>
                        <td> <input type="hidden" name="prodid" value="<?php echo $_GET['prodid'];?>"><br></td>
                    </tr>
                    <tr>
                        <td><label>Password</label></td>
                        <td> <input type="password" name="lpassword" required="true"><br></td>
                    </tr>
                     <tr>
                         <td><input type="submit" value="Login"></td>
                        <td><input type="reset" value="Reset"></td>
                    </tr>
                    <tr>
                        <td align="center"><a href="register.php">New Account</a></td>
                    </tr>
                </tbody>
            </table>
           </fieldset>
        </form>
    </center>
</body>
</html>