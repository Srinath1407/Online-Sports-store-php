<html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script type = "text/javascript" >

   function preventBack(){window.history.forward();}

    setTimeout("preventBack()", 0);

    window.onunload=function(){null};

</script>
<style re>
    body, html {
    height: 100%;
    margin: 0;
  background-repeat: no-repeat;

}
</style>
    </head>
    <body>
        <table cellspacing="50" width="100%" id="products" style="margin-top: 90px">
            <?php
          session_start();
          $user=$_SESSION["username"];
          $mail=$_SESSION["usermail"];
          $conn=new mysqli("localhost:3306", "project", "project", "projectdb");
          if($conn->connect_error)
            {
                die("Connection failed:$conn->connect_error");
            }
          $qry = "select is_admin from registration where email like '$mail'";
          $res =$conn->query($qry);
          if($res)
          {
              while($row=$res->fetch_assoc())
              {
               $admin=$row["is_admin"];
              }
          } 
            if($admin==1)
            {
                include 'adminmenu.php';
            }
            else
            {
                include 'home.php';
            }


$sql = "select productid,concat(company,' ',productname,' ',model) product,price,image,discount,aftdisc from productdetails where is_remove=0";
$result =$conn->query($sql);

$qry2="select prodid from cartdetails where email='$mail' and is_added=1";
$test=$conn->query($qry2);
if($test)
          {
              while($row=$test->fetch_assoc())
              {
               $prodid=$row["prodid"];
              }
          } 
if($result)
{
    $count=0;
    $rowcount=1;
    while($row=$result->fetch_assoc())
    {
       $image = $row['image']; 
       $product=$row['product'];
       $price=$row['price'];
       $pid=$row["productid"];
       $discount=$row["discount"];
       $aftdisc=$row["aftdisc"];
       $image_src = "uploads/".$image;
      
            if($count==4) 
            {
               print "</tr>";
               $count = 0;
            }
            if ($count == 0) {
            print "<tr align='center'>";
        }
        print "<td>";
            
            echo "<img src='$image_src' height='180px' width='200px'><br><a href='productdisplay.php?pid=$pid'>$product</a><br><h4>Rs. ".$aftdisc." $discount% OFF <del>$price</del><h4>"."";
            if($admin!=1 and $count1==0)
            {
              //  echo ""."<a href='addtocart.php?pid=$pid' class='btn btn-primary' id='addcart$rowcount' onclick='hideadd()'>Add to cart</a>";
            }     
            if($prodid==$pid)
            {
               // echo ""."<a href='cart.php' class='btn btn-primary' id='gocart$rowcount'>Go to cart</a>";
            }
            $count++;
            $rowcount++;
            print "</td>";
        }
        if ($count > 0) {
        print "</tr>";
    }
}

?>
        
        </table>
    </body>
    
</html>

