<?php
        require 'PHPMailer-5.2.25/PHPMailerAutoload.php';
        $mail = new PHPMailer;
        $email="13cp020@gmail.com";//to reciepients
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = '13cp020@gmail.com';
        $mail->Password = 'Srinath.g14';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->addAddress($email);
        $mail->Subject = '';
        $mail->isHTML(true);

        $mailContent = "<h1>Jungkook</h1>";
        $mail->Body = $mailContent;//body or content
        if(!$mail->send()){
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
        }else{
        echo 'Message has been sent';
        }
        ?>