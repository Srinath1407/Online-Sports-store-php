<html>
    <head>
        <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
        <script>
                function check(){
                    var email=document.getElementById("mail").value;
                    var mbno=document.getElementById("mobile").value;
                    var emMatch=/^([a-z]{6,20}|[A-Z]{6,20})|[0-9]{0,}\@[a-z]{5,}\.[a-z]{3,}$/;
                    var mbmatch=/^[6-9]{1}[0-9]{9}$/;
                    if(!mbno.match(mbmatch)){
                                    alert("Please enter a valid mobile number");
                    }
                    else if(!email.match(emMatch)){
                                    alert("Please enter a valid email id");
                    }	
                    else
                    {
                        $("#form").submit();
                    }
            }
            function emailcheck()
            {
                var email=document.getElementById("mail").value;
                var emMatch=/^([a-z]{6,20}|[A-Z]{6,20})|[0-9]{0,}\@[a-z]{5,}\.[a-z]{3,}$/;
                if(!email.match(emMatch))
                {
                    alert("Please enter a valid email id");
                }
            }
          function passwordCheck()
            {
                var regularExpression = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;
                 var pwd=document.getElementById("pwd").value;
                 alert(pwd);
                 if(!pwd.match(regularExpression))
                {
                    alert("Please enter a valid password");
                }
            }
            
                    </script>
                
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <style>
            fieldset {
    display: block;
    margin-left: 2px;
    margin-right: 2px;
    padding-top: 0.35em;
    padding-bottom: 0.625em;
    padding-left: 0.75em;
    padding-right: 0.75em;
    border: 2px groove (internal value);
}

body, html {
    height: 100%;
    margin: 0;
  background-repeat: no-repeat;

}

            </style>
            
    </head>
    <body class="container-fluid">
  
         <?php include 'home.php';?>
    <center>
       
        <form  action="registerdetails.php" method="POST" id="form">
             <fieldset>
            <legend>
      <h2>Registration Form</h2></legend>
            <table border="0"style="margin-top: 10px">
                <tbody>
                    <tr >
                        <td><label>Name</label></td>
                        <td> <input type="text" name="name" required="true"><br></td>
                    </tr>                  
                    <tr>
                        <td> <label>Mobile Number</label></td>
                        <td><input type="text" name="mobile"id="mobile" required="true" maxlength="10"></td>
                    </tr>
                    <tr>
                        <td><label>Email</label></td>
                        <td><input type="text" name="email" id="mail" required="true" onblur="emailcheck()"></td>
                    </tr>
                    <tr>
                        <td> <label>CreatePassword</label></td>
                        <td><input type="password" name="password" id="pwd" required="true" minlength="8" onblur="passwordCheck()"></td>
                    </tr>
                    <tr>
                        <td> <label>Confirm Password</label></td>
                        <td><input type="password" name="cpwd" id="cpwd" required="true" minlength="8"></td>
                    </tr>
                    <tr>
                        <td><input type="button" value="Register" onclick="check()"></td>
                        <td><input type="reset" value="Reset"></td>
                    </tr>
                    
                     <tr>
                         <td align="left"><a href="login.php" >Already registered, Click here to login</a></td>
                    </tr>
                </tbody>
            </table>         
            
             </fieldset>
         </form>
        </center>
    </body>
</html>



